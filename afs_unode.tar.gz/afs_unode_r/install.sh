#!/bin/bash
c_user="$USER"
start_path="$PWD"
echo "Hey, it is going to install upload node now"
echo "During installation, you need to provide a host port"
echo "Are you ready?(y/n)"
read choice
if [ "$choice" = "n" ] ; then
        echo "The installation has been terminated"
        exit 0
fi
echo "OK, lets get start"

echo "Please provide the host port of this upload node (Default: 8092): "
read host_port
if [ -z "$host_port" ] ;
then host_port="8092"
fi

echo "Please input log files path (Default: ./log/): "
read log_path
if [ -z "$log_path" ] ;
then log_path="./log/"
fi

cat <<EOF > conf.json
{
    "max_upload_thread" : 10,
    "block_size" : 1,
    "uploaddir" : "./upload_dir/",
    "afsdir" : "./afs_dir/",
    "port" : "$host_port",
    "log_file_path" : "./log/",
    "rnode" : [
        {
            "address" : "http://39.108.80.53:8090"
        },
        {
            "address" : "http://139.159.244.231:8090"
        }
    ]
}
EOF
echo "Creating a service for our program"
cat <<EOF >  /etc/systemd/system/unode.service
[Unit]
Description=This is the service of unode
After=network-online.target
StartLimitIntervalSec=0

[Service]
Type=simple
User=${c_user}
WorkingDirectory=${start_path}
ExecStart=${start_path}/main

[Install]
WantedBy=multi-user.target
EOF
echo "Congratulation !! The installation has completed"
